import { createRoot } from "react-dom/client";
import App from "./App.jsx";

const divRoot = document.getElementById("root");

createRoot(divRoot).render(<App />);
